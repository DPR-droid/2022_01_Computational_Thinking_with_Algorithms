n = int(input('Please enter a number to square: ')) 
for i in range(1,n+1):
    print("%s² = %s"%(i,i**2))